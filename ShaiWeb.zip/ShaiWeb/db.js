//DataBase file

var mongoose = require('mongoose');//mongoose.set('debug', true);
var uniqueValidator = require('mongoose-unique-validator');

mongoose.Promise = Promise;

let options = { useNewUrlParser : true, autoReconnect : true, promiseLibrary : global.Promise, useUnifiedTopology: true};
var dbString = "mongodb+srv://shai:SXRCW052@cluster0-ogc7m.mongodb.net/test?retryWrites=true&w=majority";
mongoose.connect(dbString);

/*run().then(() => console.log('done')).catch(error => console.error(error.stack));
async function run() {
  await mongoose.connect(config.dbConnectionString, options);
}*/


var db = mongoose.connection;
//db.on('error', console.error.bind(console, ''));

db.once('open',function () {
    console.log('\nConnected: ' + db.readyState);
}).on('error',function (error) {
	console.log("Ready state: " + db.readyState);
    console.log('CONNECTION ERROR:',error);
});

var Schema = mongoose.Schema;

var userSchema, Users;  //Users' table

CreateTables ();


//Creates tables and schemes
function CreateTables () {
	try {
		userSchema = new Schema({
			username: { type: String, unique : true, required : true , uniqueCaseInsensitive: true },
      password: { type: String, required: true, minlength: 6 },
			name: { type: String, required : true },
      email: { type: String, required : true, unique : true }
		});
    userSchema.plugin(uniqueValidator, 'Error, expected {PATH} to be unique.');
		Users = mongoose.model('users', userSchema);

	}
	catch (e) { console.log (e) }
}

module.exports.db = db;
module.exports.userSchema = userSchema;
module.exports.Users = Users;
