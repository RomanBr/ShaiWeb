var mongoose = require('mongoose');
var express = require('express');
const url = require('url');

var router = express.Router();

var mongoDB = require('./db');
var Schema = mongoose.Schema;
var userSchema = mongoDB.userSchema, Users = mongoDB.Users, db = mongoDB.db;

var user = null;
router.get('/', function(req, res, next) {
	if (user != null) res.render('game.ejs', {user: user});
	else res.render('login.ejs');
});

router.get('/logout', function(req, res, next) {
		user = null;
		res.render('/');
});

router.get('/login', function(req, res, next) {
		res.render('login.ejs');
});

router.post('/login', function(req, res, next) {
  console.log (req.body.email);
  Users.findOne ({ email: req.body.email }, function (err, _user) {
      console.log (_user);
	  if (err) {
        console.error(err);
        res.status(401).send({ err: err, message: "err", failed: false });
      }

      else {
         if (_user.password != req.body.password) {
             res.status(401).send({ message: "wrong password", failed: true });
         }
		 else {
			 user = _user;
			 res.send ({ user: _user, message: "Logged with the user: " + user.username } );
		 }
       }
  });
});


router.get('/game', function(req, res, next) {
		if (user == null) res.render ("/login");
		else res.render('game.ejs');
});


router.get('/signup', function(req, res, next) {
    if (user != null) res.redirect ("/games");
    else res.render('signup.ejs');
});

router.post('/SETUSER', function(req, res, next) {

  	var newUser = {
  		username: req.body.username,
  		name: req.body.name,
  		email: req.body.email,
  		password: req.body.password
  	};

  	newUser = new Users (newUser);
  	newUser.save(function (err, _user) {
  		if (err) {
  			console.error(err);
  			res.status(401).send({ message: "user already exitsts" });
  		}
  		else {
         user = _user;
         res.send ({ user: _user.username, message: "User created successfuly" });
  	  }
  });
});

module.exports = router;
